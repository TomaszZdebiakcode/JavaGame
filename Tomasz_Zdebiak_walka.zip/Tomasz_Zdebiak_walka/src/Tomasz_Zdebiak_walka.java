import Game.Game;

public class Tomasz_Zdebiak_walka {

    public static void main(String[] args) {
        Game game = new Game();
        game.startGame();

    }

}

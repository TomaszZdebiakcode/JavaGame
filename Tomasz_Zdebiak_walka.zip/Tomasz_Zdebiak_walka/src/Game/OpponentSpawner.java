package Game;
import java.util.Random;

// Klasa pomocnicza OpponentSpawner
public class OpponentSpawner {
    private static final Random RANDOM = new Random();

    public static Unit spawn() {
        // Losowanie liczby od 0 do 99
        int roll = RANDOM.nextInt(100);

        if (roll < 60) { // 60% szansy na Imp
            return new Imp();
        } else if (roll < 90) { // 30% szansy na Goblin (od 60 do 89)
            return new Goblin();
        } else { // 10% szansy na Dragon (od 90 do 99)
            return new Dragon();
        }
    }
}
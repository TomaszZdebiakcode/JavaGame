package Game;

import java.util.Random;

public abstract class Unit {

    // Atrybuty
    static final Random random = new Random(); // Generowanie losowych liczb
    String identifier; // Identyfikator jednostki
    int maxHealthPoints; // Maksymalna liczba punktów zdrowia
    int maxDamage; // Maksymalna liczba zadawanych obrażeń
    int healthPoints; // Aktualna liczba punktów zdrowia

    // Konstruktor
    public Unit(String identifier, int maxHealthPoints, int maxDamage) {
        this.identifier = identifier;
        this.maxHealthPoints = maxHealthPoints;
        this.maxDamage = maxDamage;
        this.healthPoints = maxHealthPoints; // Stan początkowy walki
    }

    // Konstruktor
    public Unit(String identifier, int maxHealthPoints, int maxDamage, int healthPoints) {
        this.identifier = identifier;
        this.maxHealthPoints = maxHealthPoints;
        this.maxDamage = maxDamage;
        this.maxHealthPoints = maxHealthPoints; // Stan początkowy walki
        this.healthPoints = healthPoints;
    }

    // Metoda do wyświetlania statystyk jednostki
    public void displayStats(){
        System.out.println("_________________________________________");
        System.out.println("Unit: " + this.identifier);
        System.out.println("HP: " + this.healthPoints);
        System.out.println("Max DMG: " + this.maxDamage);
        System.out.println("_________________________________________");

    }

    // Metoda do zapisywania atrybutów
    public String toCSV() {
        return identifier + "," + maxHealthPoints + "," + maxDamage + "," + healthPoints;
    }


    // Metoda sprawdzająca, czy jednostka żyje
    public boolean isAlive() {
        return healthPoints > 0;
    }

    // Metoda do otrzymywania obrażeń
    public void receiveDamage(int damage) {
        this.healthPoints -= damage;
        if (this.healthPoints < 0) {
            this.healthPoints = 0; // Punkty zdrowia nie mogą być ujemne
        }
    }

    // Metoda do ataku
    public void attack(Unit target) {
        int damage = random.nextInt(maxDamage + 1); // Losowanie obrażeń
        if (damage > 0) {
            System.out.printf("%s attacked %s , they took %d DMG!\n", identifier, target.identifier, damage);
            target.receiveDamage(damage);
        } else {
            System.out.printf("%s missed the attack!\n", identifier);
        }
    }


}

// Klasa Imp dziedzicząca po Unit
class Imp extends Unit {

    // Konstruktor bezparametrowy
    public Imp() {
        super("Imp", 20, 10); // Stałe wartości dla imienia, punktów zdrowia i obrażeń
    }
    public Imp(String identifier, int maxHealthPoints, int maxDamage, int healthPoints) {
        super(identifier, maxHealthPoints, maxDamage, healthPoints);
    }

}

class Goblin extends Unit {

    // Konstruktor bezparametrowy
    public Goblin() {
        super("Goblin", 30, 15); // Stałe wartości dla imienia, punktów zdrowia i obrażeń
    }
    public Goblin(String identifier, int maxHealthPoints, int maxDamage, int healthPoints) {
        super(identifier, maxHealthPoints, maxDamage, healthPoints);
    }
}

class Dragon extends Unit {

    // Konstruktor bezparametrowy
    public Dragon() {
        super("Dragon", 50, 20); // Stałe wartości dla imienia, punktów zdrowia i obrażeń
    }
    public Dragon(String identifier, int maxHealthPoints, int maxDamage, int healthPoints) {
        super(identifier, maxHealthPoints, maxDamage, healthPoints);
    }
}

// Klasa Hero dziedzicząca po Unit
class Hero extends Unit {

    // Dodatkowy atrybut
    private int maxHealingPower; // Maksymalna wartość leczenia
    private int currentLevel; // Aktualny poziom gracza

    // Konstruktor
    public Hero(String name, int maxHealthPoints, int maxDamage, int healthPoints, int level) {
        super(name, 40, 20); // Stałe wartości dla punktów zdrowia i obrażeń, imię jako parametr
        this.maxHealingPower = 25; // Ustalona maksymalna wartość leczenia
    }
    public Hero(String identifier, int maxHealthPoints, int maxDamage, int healthPoints) {
        super(identifier, maxHealthPoints, maxDamage, healthPoints);
        this.maxHealingPower = maxHealthPoints;
        this.currentLevel = 1;
    }

    // Metoda umożliwiająca leczenie
    public void heal() {
        int healAmount = new Random().nextInt(this.maxHealingPower) + 1; // Losowanie od 1 do maxHealingPower
        int newHealth = this.healthPoints + healAmount;
        if (newHealth > this.maxHealthPoints) {
            newHealth = this.maxHealthPoints; // Ograniczenie do maksymalnych punktów zdrowia
        }
        this.healthPoints = newHealth;
        System.out.printf("%s heals for %d points! \n", this.identifier, healAmount);
    }

    // Metoda umożliwiająca poddanie się
    void surrender() {
        System.out.printf("%s surrenders \n", this.identifier);
        this.healthPoints = 0; // Ustawienie zdrowia na 0
    }

    public String toCSV() {
        return identifier + "," + maxHealthPoints + "," + maxDamage + "," + healthPoints + "," + currentLevel + maxHealingPower;
    }

    // Metoda podnoszaca poziom
    void levelup() {
        this.maxHealingPower += 2;
        this.maxDamage += 2;
        this.maxHealthPoints += 2;
    }

    // Metoda do wyświetlania statystyk jednostki
    public void displayStats() {
        System.out.println("_________________________________________");
        System.out.println("Unit: " + this.identifier);
        System.out.println("HP: " + this.healthPoints);
        System.out.println("Max DMG: " + this.maxDamage);
        System.out.println("Current level: " + this.currentLevel);
        System.out.println("Max Health: " + this.maxHealthPoints);
        System.out.println("Max Healing Power: " + this.maxHealingPower);
        System.out.println("_________________________________________");
    }
    // Metoda wyświetlająca dostępne akcje
    void displayActions() {
        System.out.println("_________________________________________");
        System.out.println("1. Attack");
        System.out.println("2. Heal");
        System.out.println("3. Give up");
        System.out.println("4. Save and Exit");
        System.out.println("_________________________________________");
    }
}



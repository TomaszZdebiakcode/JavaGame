package Game;
import java.io.IOException;
import java.util.Scanner;

public class Game {

    private Hero hero;
    private Unit opponent;
    private Scanner scanner;
    private SaveSystem saveSystem;

    // Konstruktor
    public Game() {
        this.saveSystem = new SaveSystem("hero.txt","opponent.txt");
        this.scanner = new Scanner(System.in);
    }

    // Metoda umożliwiająca utworzenie Bohatera
    public void createHero() {
        System.out.print("Podaj imię swojego bohatera: ");
        String name = scanner.nextLine();
        this.hero = new Hero(name, 30, 50, 30, 1);
    }

    // Metoda rozpoczynająca pojedynek
    public void combat() {
        int choice;
        while (hero.isAlive() && opponent.isAlive()) {
            hero.displayStats();
            opponent.displayStats();
            hero.displayActions();
            choice = scanner.nextInt();
            handleChoice(choice,opponent);
            if (opponent.isAlive() && hero.isAlive()) {
                opponent.attack(hero);
            }
        }
    }

    // Metoda wczytująca zapisaną grę
    public void loadGame() {
        try {
            this.hero = this.saveSystem.loadHero("hero.txt");
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        try {
            this.opponent = this.saveSystem.loadOpponent("opponent.txt");
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    // Metoda rozpoczynająca nową grę
    public void newGame() {
        createHero();
        opponent = new Imp(); // Nowy przeciwnik
        combat();
        Unit winner = getWinner();
        System.out.printf("The winner is: %s\n", winner.identifier);
    }

    // Metoda wykonująca pętle do śmierci bohatera
    public void gameloop() {
        while (true) {
            if (opponent == null) {
                opponent = OpponentSpawner.spawn();
                System.out.println("A wild " + opponent + " appeared!");
            }
            this.combat();

            if (!opponent.isAlive() && hero.isAlive()) {
                System.out.println("Hero won the duel!");
                hero.levelup();
                opponent = null;
                System.out.println("Another opponent approaches...");
            } else {
                System.out.println("Hero was defeated by " + opponent + ". Game over.");
                break;
            }
        }
    }

    // Metoda obsługująca wybór akcji
    private void handleChoice(int choice, Unit opponent) {
        switch (choice) {
            case 1:
                hero.attack(opponent);
                return;
            case 2:
                hero.heal();
                return;
            case 3:
                hero.surrender();
                return;
            case 4:
                try {
                    this.saveSystem.saveGame(hero, opponent);
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
                System.out.println("Game has been saved. See you!");
                System.exit(0);
            default:
                System.out.println("ERORRRR. Try again.");
        }

    }

    // Metoda zwracająca obiekt zwycięskiej jednostki
    public Unit getWinner() {
        if (hero.isAlive()) {
            return hero;
        } else {
            return opponent;
        }
    }

    // Metoda rozpoczynająca grę
    // Metoda rozpoczynająca grę
    public void startGame() {
        System.out.println("Choice option:");
        System.out.println("1. New Game");
        System.out.println("2. Load Game");
        int choice = scanner.nextInt();
        scanner.nextLine(); // Konsumowanie nowej linii

        switch (choice) {
            case 1:
                newGame();
                break;
            case 2:
                loadGame();
                gameloop();
                break;
            default:
                System.out.println("Error, starting new game");
                newGame();
        }
    }

    public static void main(String[] args) {
        Game game = new Game();
        game.startGame();
    }
}
package Game;

import java.io.*;
import java.util.Scanner;

public class SaveSystem {
    private File heroFile;
    private File opponentFile;

    public SaveSystem(String heroFileName,String opponentFileName ) {
        heroFile = new File(heroFileName);
        opponentFile = new File(opponentFileName);
    }

    public void saveGame(Hero hero, Unit opponent) throws IOException {
        initializeGameFiles();
        try (FileWriter heroWriter = new FileWriter(heroFile);
             FileWriter opponentWriter = new FileWriter(opponentFile)) {
            heroWriter.write(hero.toCSV());
            opponentWriter.write(opponent.toCSV());
        }
    }

    public static Hero loadHero(String heroFile) throws IOException {
        try (Scanner scanner = new Scanner(new File(heroFile))) {
            if (scanner.hasNextLine()) {
                String[] data = scanner.nextLine().split(",");
                String identifier = data[0];
                int maxHealthPoints = Integer.parseInt(data[1]);
                int maxDamage = Integer.parseInt(data[2]);
                int healthPoints = Integer.parseInt(data[3]);
                int level = Integer.parseInt(data[4]);
                return new Hero(identifier, maxHealthPoints, maxDamage, healthPoints, level);
            } else {
                throw new IOException("Hero file is empty.");
            }
        }
    }

    public static Unit loadOpponent(String opponentFile) throws IOException {
        try (Scanner scanner = new Scanner(new File(opponentFile))) {
            if (scanner.hasNextLine()) {
                String[] data = scanner.nextLine().split(",");
                String identifier = data[0];
                int maxHealthPoints = Integer.parseInt(data[1]);
                int maxDamage = Integer.parseInt(data[2]);
                int healthPoints = Integer.parseInt(data[3]);

                if (identifier.startsWith("Imp")) {
                    return new Imp(identifier, maxHealthPoints, maxDamage, healthPoints);
                } else if (identifier.startsWith("Goblin")) {
                    return new Goblin(identifier, maxHealthPoints, maxDamage, healthPoints);
                } else if (identifier.startsWith("Dragon")) {
                    return new Dragon(identifier, maxHealthPoints, maxDamage, healthPoints);
                } else {
                    throw new IOException("Unknown opponent type.");
                }
            } else {
                throw new IOException("Opponent file is empty.");
            }
        }
    }

    private void initializeGameFiles() {
        initializeFile(heroFile);
        initializeFile(opponentFile);
    }

    private void initializeFile(File file) {
        try {
            if (file.createNewFile()) {
                // file created
            } else {
                file.delete();
                file.createNewFile();
            }
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }
}
